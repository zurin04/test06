#!/bin/bash

# VPS Startup Script for CryptoHub
set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${YELLOW}🚀 Starting CryptoHub on VPS...${NC}"

# Check if PostgreSQL is running
if ! systemctl is-active --quiet postgresql; then
    echo -e "${YELLOW}📚 Starting PostgreSQL...${NC}"
    sudo systemctl start postgresql
    sudo systemctl enable postgresql
fi

# Set environment variables from .env.production if it exists
if [ -f .env.production ]; then
    echo -e "${YELLOW}📝 Loading production environment...${NC}"
    export $(cat .env.production | grep -v '^#' | xargs)
fi

# Check database connection
echo -e "${YELLOW}🗄️ Checking database connection...${NC}"
if psql -h localhost -U cryptohub_user -d cryptohub_db -c "SELECT 1;" > /dev/null 2>&1; then
    echo -e "${GREEN}✅ Database connection successful${NC}"
else
    echo -e "${RED}❌ Database connection failed. Please check your PostgreSQL setup.${NC}"
    exit 1
fi

# Run database migrations
echo -e "${YELLOW}🔄 Running database migrations...${NC}"
npm run db:push

# Build the application
echo -e "${YELLOW}🔨 Building application...${NC}"
npm run build

# Start the application
echo -e "${YELLOW}🌟 Starting CryptoHub application...${NC}"
NODE_ENV=production npm start