#!/bin/bash

# Database Initialization Script for CryptoHub VPS
set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${YELLOW}🗄️ Initializing CryptoHub database...${NC}"

# Database credentials
DB_NAME="cryptohub_db"
DB_USER="cryptohub_user"
DB_PASSWORD="cryptohub_secure_password_2025"

# Create database and user
echo -e "${YELLOW}👤 Creating database user and database...${NC}"
sudo -u postgres psql << EOF
-- Drop existing database and user if they exist
DROP DATABASE IF EXISTS ${DB_NAME};
DROP ROLE IF EXISTS ${DB_USER};

-- Create new user
CREATE ROLE ${DB_USER} WITH LOGIN PASSWORD '${DB_PASSWORD}';

-- Create database
CREATE DATABASE ${DB_NAME} WITH OWNER ${DB_USER};

-- Grant privileges
GRANT ALL PRIVILEGES ON DATABASE ${DB_NAME} TO ${DB_USER};
GRANT USAGE ON SCHEMA public TO ${DB_USER};
GRANT CREATE ON SCHEMA public TO ${DB_USER};
ALTER ROLE ${DB_USER} CREATEDB;

-- Connect to the new database and set up permissions
\c ${DB_NAME}
GRANT ALL ON SCHEMA public TO ${DB_USER};
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO ${DB_USER};
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO ${DB_USER};
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO ${DB_USER};
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO ${DB_USER};

-- Exit
\q
EOF

echo -e "${GREEN}✅ Database and user created successfully${NC}"

# Update environment file with correct credentials
echo -e "${YELLOW}📝 Creating environment configuration...${NC}"
cat > .env.production << EOF
# VPS Production Environment Configuration
NODE_ENV=production
PORT=5000

# Database Configuration
DATABASE_URL=postgresql://${DB_USER}:${DB_PASSWORD}@localhost:5432/${DB_NAME}
PGHOST=localhost
PGPORT=5432
PGUSER=${DB_USER}
PGPASSWORD=${DB_PASSWORD}
PGDATABASE=${DB_NAME}

# Session Configuration
SESSION_SECRET=cryptohub_vps_session_secret_$(date +%s)_secure

# Security Settings
TRUST_PROXY=1

# Disable Replit-specific variables for VPS
# REPL_ID=
# REPLIT_DOMAINS=
# ISSUER_URL=
EOF

echo -e "${GREEN}✅ Environment configuration created${NC}"

# Test database connection
echo -e "${YELLOW}🧪 Testing database connection...${NC}"
if PGPASSWORD=${DB_PASSWORD} psql -h localhost -U ${DB_USER} -d ${DB_NAME} -c "SELECT 1;" > /dev/null 2>&1; then
    echo -e "${GREEN}✅ Database connection successful${NC}"
else
    echo -e "${RED}❌ Database connection failed${NC}"
    exit 1
fi

echo -e "${GREEN}🎉 Database initialization completed successfully!${NC}"
echo -e "${YELLOW}📋 Next steps:${NC}"
echo -e "1. Load environment: source .env.production"
echo -e "2. Run migrations: npm run db:push"
echo -e "3. Start application: npm start"