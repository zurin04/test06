import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Link } from "wouter";
import { Code, ArrowLeft, Copy, ExternalLink } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function APIDocumentation() {
  const { toast } = useToast();

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied to clipboard",
      description: "Code snippet copied successfully.",
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-6xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <Link href="/">
            <Button variant="ghost" className="mb-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </Link>
          <h1 className="text-3xl font-bold mb-4">API Documentation</h1>
          <p className="text-xl text-muted-foreground">
            Integrate with CryptoHub's RESTful API
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          <div className="lg:col-span-3">
            <Tabs defaultValue="overview" className="space-y-6">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="auth">Authentication</TabsTrigger>
                <TabsTrigger value="posts">Posts</TabsTrigger>
                <TabsTrigger value="users">Users</TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Getting Started</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-muted-foreground">
                      The CryptoHub API provides programmatic access to community data, posts, and user information.
                      All API endpoints are REST-based and return JSON responses.
                    </p>
                    <div className="space-y-2">
                      <h3 className="font-semibold">Base URL</h3>
                      <div className="bg-muted p-3 rounded-lg font-mono text-sm">
                        https://your-app.replit.app/api
                      </div>
                    </div>
                    <div className="space-y-2">
                      <h3 className="font-semibold">Response Format</h3>
                      <p className="text-sm text-muted-foreground">
                        All responses are in JSON format with consistent error handling.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="auth" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Authentication</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-4">
                      <div>
                        <h3 className="font-semibold mb-2">Login</h3>
                        <Badge variant="outline" className="mb-2">POST</Badge>
                        <div className="bg-muted p-3 rounded-lg">
                          <div className="flex justify-between items-center">
                            <code className="text-sm">/api/auth/login</code>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => copyToClipboard('/api/auth/login')}
                            >
                              <Copy className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                        <div className="mt-4">
                          <h4 className="font-medium mb-2">Request Body</h4>
                          <pre className="bg-muted p-3 rounded-lg text-sm overflow-x-auto">
{`{
  "email": "user@example.com",
  "password": "securepassword"
}`}
                          </pre>
                        </div>
                      </div>

                      <div>
                        <h3 className="font-semibold mb-2">Register</h3>
                        <Badge variant="outline" className="mb-2">POST</Badge>
                        <div className="bg-muted p-3 rounded-lg">
                          <div className="flex justify-between items-center">
                            <code className="text-sm">/api/auth/signup</code>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => copyToClipboard('/api/auth/signup')}
                            >
                              <Copy className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="posts" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Posts Endpoints</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div>
                      <h3 className="font-semibold mb-2">Get Posts</h3>
                      <Badge variant="outline" className="mb-2">GET</Badge>
                      <div className="bg-muted p-3 rounded-lg">
                        <div className="flex justify-between items-center">
                          <code className="text-sm">/api/posts</code>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => copyToClipboard('/api/posts')}
                          >
                            <Copy className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                      <div className="mt-4">
                        <h4 className="font-medium mb-2">Query Parameters</h4>
                        <ul className="text-sm text-muted-foreground space-y-1">
                          <li><code>category</code> - Filter by category (testnets, node-setup, social-tasks, airdrops)</li>
                          <li><code>search</code> - Search posts by title and content</li>
                          <li><code>sortBy</code> - Sort by recent, popular, or trending</li>
                          <li><code>limit</code> - Number of posts to return (default: 20)</li>
                          <li><code>offset</code> - Pagination offset</li>
                        </ul>
                      </div>
                    </div>

                    <div>
                      <h3 className="font-semibold mb-2">Create Post</h3>
                      <Badge variant="outline" className="mb-2">POST</Badge>
                      <div className="bg-muted p-3 rounded-lg">
                        <div className="flex justify-between items-center">
                          <code className="text-sm">/api/posts</code>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => copyToClipboard('/api/posts')}
                          >
                            <Copy className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                      <div className="mt-4">
                        <h4 className="font-medium mb-2">Request Body</h4>
                        <pre className="bg-muted p-3 rounded-lg text-sm overflow-x-auto">
{`{
  "title": "Setting up Starknet Node",
  "content": "Step-by-step guide...",
  "category": "node-setup",
  "tags": ["starknet", "node", "guide"],
  "imageUrl": "https://example.com/image.jpg"
}`}
                        </pre>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="users" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>User Endpoints</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div>
                      <h3 className="font-semibold mb-2">Get Current User</h3>
                      <Badge variant="outline" className="mb-2">GET</Badge>
                      <div className="bg-muted p-3 rounded-lg">
                        <div className="flex justify-between items-center">
                          <code className="text-sm">/api/auth/user</code>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => copyToClipboard('/api/auth/user')}
                          >
                            <Copy className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h3 className="font-semibold mb-2">Get User Profile</h3>
                      <Badge variant="outline" className="mb-2">GET</Badge>
                      <div className="bg-muted p-3 rounded-lg">
                        <div className="flex justify-between items-center">
                          <code className="text-sm">/api/users/:userId</code>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => copyToClipboard('/api/users/:userId')}
                          >
                            <Copy className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Quick Links</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button variant="outline" className="w-full justify-start">
                  <Code className="w-4 h-4 mr-2" />
                  Postman Collection
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <ExternalLink className="w-4 h-4 mr-2" />
                  OpenAPI Spec
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Code className="w-4 h-4 mr-2" />
                  SDKs & Libraries
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Rate Limits</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="text-sm">
                  <p className="font-medium">Authenticated Requests</p>
                  <p className="text-muted-foreground">1000 requests/hour</p>
                </div>
                <div className="text-sm">
                  <p className="font-medium">Public Endpoints</p>
                  <p className="text-muted-foreground">100 requests/hour</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Status Codes</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm">
                <div><code>200</code> - Success</div>
                <div><code>201</code> - Created</div>
                <div><code>400</code> - Bad Request</div>
                <div><code>401</code> - Unauthorized</div>
                <div><code>403</code> - Forbidden</div>
                <div><code>404</code> - Not Found</div>
                <div><code>500</code> - Server Error</div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}