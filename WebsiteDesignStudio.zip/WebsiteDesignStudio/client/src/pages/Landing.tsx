import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ThemeToggle } from "@/components/ThemeProvider";
import { Link } from "wouter";
import { 
  FlaskConical, 
  Server, 
  CheckSquare, 
  Gift,
  Users,
  TrendingUp,
  Shield,
  Zap
} from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted">
      {/* Navigation */}
      <nav className="border-b bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="w-8 h-8 bg-crypto-gradient rounded-lg flex items-center justify-center mr-3">
                <FlaskConical className="w-4 h-4 text-white" />
              </div>
              <h1 className="text-xl font-bold text-crypto-gradient">CryptoHub</h1>
            </div>
            <div className="flex items-center space-x-4">
              <ThemeToggle />
              <Button onClick={() => window.location.href = '/api/login'} className="bg-crypto-gradient hover:opacity-90">
                Sign In
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <div className="inline-flex items-center px-4 py-2 bg-crypto-blue/10 rounded-full mb-8">
            <Zap className="w-4 h-4 text-crypto-blue mr-2" />
            <span className="text-sm font-medium text-crypto-blue">The Ultimate Crypto Community Platform</span>
          </div>
          
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            Your Gateway to{" "}
            <span className="text-crypto-gradient">Crypto Testnets</span>
            {" "}& Airdrops
          </h1>
          
          <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto">
            Join thousands of crypto enthusiasts sharing testnet guides, node setup tutorials, 
            social tasks, and airdrop opportunities. Build your crypto knowledge and earn rewards.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Button 
              size="lg" 
              className="bg-crypto-gradient hover:opacity-90 text-lg px-8 py-3"
              onClick={() => window.location.href = '/api/login'}
            >
              Get Started Free
            </Button>
            <Button size="lg" variant="outline" className="text-lg px-8 py-3">
              Explore Community
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-3xl mx-auto">
            <div className="text-center">
              <div className="text-3xl font-bold text-crypto-blue mb-2">10k+</div>
              <div className="text-muted-foreground">Active Users</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-crypto-purple mb-2">500+</div>
              <div className="text-muted-foreground">Testnet Guides</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-crypto-emerald mb-2">$2M+</div>
              <div className="text-muted-foreground">Airdrop Rewards</div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-muted/30">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Everything You Need for <span className="text-crypto-gradient">Crypto Success</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              From testnet participation to airdrop hunting, we've got all the tools and community support you need.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-12 h-12 bg-crypto-blue/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <FlaskConical className="w-6 h-6 text-crypto-blue" />
                </div>
                <CardTitle className="text-lg">Testnet Guides</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Step-by-step guides for participating in blockchain testnets and earning potential rewards.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-12 h-12 bg-crypto-cyan/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Server className="w-6 h-6 text-crypto-cyan" />
                </div>
                <CardTitle className="text-lg">Node Setup</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Complete tutorials for setting up validators, RPC nodes, and infrastructure for various chains.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-12 h-12 bg-crypto-emerald/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <CheckSquare className="w-6 h-6 text-crypto-emerald" />
                </div>
                <CardTitle className="text-lg">Social Tasks</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Daily social media tasks and community activities to increase your airdrop eligibility.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-12 h-12 bg-crypto-purple/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Gift className="w-6 h-6 text-crypto-purple" />
                </div>
                <CardTitle className="text-lg">Airdrop Alerts</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Early alerts for upcoming airdrops with detailed eligibility criteria and task lists.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Categories Preview */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Explore <span className="text-crypto-gradient">Popular Categories</span>
            </h2>
            <p className="text-xl text-muted-foreground">
              Join discussions and share knowledge in these trending crypto topics
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card className="p-8 hover:shadow-xl transition-all hover:scale-105">
              <div className="flex items-center justify-between mb-6">
                <Badge className="bg-crypto-blue text-white">🧪 Testnets</Badge>
                <span className="text-sm text-muted-foreground">234 posts</span>
              </div>
              <h3 className="text-2xl font-bold mb-3">Latest Testnet Opportunities</h3>
              <p className="text-muted-foreground mb-4">
                Discover new blockchain testnets, earn testnet tokens, and position yourself for potential airdrops.
              </p>
              <ul className="space-y-2 text-sm">
                <li className="flex items-center">
                  <TrendingUp className="w-4 h-4 text-crypto-blue mr-2" />
                  StarkNet Alpha testing
                </li>
                <li className="flex items-center">
                  <TrendingUp className="w-4 h-4 text-crypto-blue mr-2" />
                  Scroll L2 deployment
                </li>
                <li className="flex items-center">
                  <TrendingUp className="w-4 h-4 text-crypto-blue mr-2" />
                  Polygon zkEVM beta
                </li>
              </ul>
            </Card>

            <Card className="p-8 hover:shadow-xl transition-all hover:scale-105">
              <div className="flex items-center justify-between mb-6">
                <Badge className="bg-crypto-purple text-white">🎁 Airdrops</Badge>
                <span className="text-sm text-muted-foreground">67 posts</span>
              </div>
              <h3 className="text-2xl font-bold mb-3">High-Value Airdrop Campaigns</h3>
              <p className="text-muted-foreground mb-4">
                Get early access to airdrop campaigns with step-by-step qualification guides and reward estimates.
              </p>
              <ul className="space-y-2 text-sm">
                <li className="flex items-center">
                  <Gift className="w-4 h-4 text-crypto-purple mr-2" />
                  LayerZero snapshot approaching
                </li>
                <li className="flex items-center">
                  <Gift className="w-4 h-4 text-crypto-purple mr-2" />
                  Arbitrum ecosystem rewards
                </li>
                <li className="flex items-center">
                  <Gift className="w-4 h-4 text-crypto-purple mr-2" />
                  zkSync Era campaigns
                </li>
              </ul>
            </Card>
          </div>
        </div>
      </section>

      {/* Community Stats */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-muted/30">
        <div className="max-w-7xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Join a <span className="text-crypto-gradient">Thriving Community</span>
          </h2>
          <p className="text-xl text-muted-foreground mb-12 max-w-2xl mx-auto">
            Connect with like-minded crypto enthusiasts and learn from experienced testnet participants
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="flex flex-col items-center">
              <div className="w-16 h-16 bg-crypto-blue/10 rounded-full flex items-center justify-center mb-4">
                <Users className="w-8 h-8 text-crypto-blue" />
              </div>
              <h3 className="text-xl font-bold mb-2">Active Community</h3>
              <p className="text-muted-foreground">
                Join thousands of active members sharing knowledge and opportunities daily
              </p>
            </div>

            <div className="flex flex-col items-center">
              <div className="w-16 h-16 bg-crypto-emerald/10 rounded-full flex items-center justify-center mb-4">
                <Shield className="w-8 h-8 text-crypto-emerald" />
              </div>
              <h3 className="text-xl font-bold mb-2">Verified Content</h3>
              <p className="text-muted-foreground">
                All guides and opportunities are community-verified for accuracy and safety
              </p>
            </div>

            <div className="flex flex-col items-center">
              <div className="w-16 h-16 bg-crypto-purple/10 rounded-full flex items-center justify-center mb-4">
                <TrendingUp className="w-8 h-8 text-crypto-purple" />
              </div>
              <h3 className="text-xl font-bold mb-2">Early Access</h3>
              <p className="text-muted-foreground">
                Get notified about new opportunities before they become mainstream
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Start Your <span className="text-crypto-gradient">Crypto Journey</span>?
          </h2>
          <p className="text-xl text-muted-foreground mb-8">
            Join CryptoHub today and discover your next big opportunity in the crypto space
          </p>
          <Button 
            size="lg" 
            className="bg-crypto-gradient hover:opacity-90 text-xl px-12 py-4"
            onClick={() => window.location.href = '/api/login'}
          >
            Join CryptoHub Now
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t bg-background/80 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <div className="w-8 h-8 bg-crypto-gradient rounded-lg flex items-center justify-center mr-3">
                  <FlaskConical className="w-4 h-4 text-white" />
                </div>
                <h3 className="text-lg font-bold text-crypto-gradient">CryptoHub</h3>
              </div>
              <p className="text-muted-foreground text-sm">
                The ultimate community platform for cryptocurrency testnets, node setups, and airdrop opportunities.
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Community</h4>
              <div className="space-y-2 text-sm text-muted-foreground">
                <Link href="/guidelines" className="block hover:text-crypto-blue transition-colors">Guidelines</Link>
                <Link href="/faq" className="block hover:text-crypto-blue transition-colors">FAQ</Link>
                <Link href="/support" className="block hover:text-crypto-blue transition-colors">Support</Link>
              </div>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Resources</h4>
              <div className="space-y-2 text-sm text-muted-foreground">
                <Link href="/api-docs" className="block hover:text-crypto-blue transition-colors">API Documentation</Link>
                <Link href="/tutorials" className="block hover:text-crypto-blue transition-colors">Tutorials</Link>
                <Link href="/blog" className="block hover:text-crypto-blue transition-colors">Blog</Link>
              </div>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Connect</h4>
              <div className="flex space-x-4">
                <a href="#" className="text-muted-foreground hover:text-crypto-blue transition-colors">Twitter</a>
                <a href="#" className="text-muted-foreground hover:text-crypto-blue transition-colors">Discord</a>
                <a href="#" className="text-muted-foreground hover:text-crypto-blue transition-colors">Telegram</a>
              </div>
            </div>
          </div>

          <div className="border-t mt-8 pt-8 text-center">
            <p className="text-muted-foreground text-sm">&copy; 2024 CryptoHub. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
