import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Shield, Users, CheckCircle, AlertTriangle, ArrowLeft } from "lucide-react";

export default function Guidelines() {
  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <Link href="/">
            <Button variant="ghost" className="mb-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </Link>
          <h1 className="text-3xl font-bold mb-4">Community Guidelines</h1>
          <p className="text-xl text-muted-foreground">
            Building a safe and productive crypto community together
          </p>
        </div>

        <div className="space-y-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Shield className="w-5 h-5 mr-2 text-crypto-blue" />
                Safety First
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <h3 className="font-semibold text-green-600">✓ Do:</h3>
                <ul className="space-y-1 text-sm text-muted-foreground ml-4">
                  <li>• Verify all testnet and airdrop opportunities before participating</li>
                  <li>• Use official project links and documentation</li>
                  <li>• Report suspicious activities or scams</li>
                  <li>• Share your own research and due diligence</li>
                </ul>
              </div>
              <div className="space-y-2">
                <h3 className="font-semibold text-red-600">✗ Don't:</h3>
                <ul className="space-y-1 text-sm text-muted-foreground ml-4">
                  <li>• Share private keys or seed phrases</li>
                  <li>• Promote obvious scams or fake projects</li>
                  <li>• Ask for financial advice or investment recommendations</li>
                  <li>• Share referral links without disclosure</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Users className="w-5 h-5 mr-2 text-crypto-emerald" />
                Community Standards
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <h3 className="font-semibold">Be Respectful</h3>
                <p className="text-sm text-muted-foreground">
                  Treat all community members with respect, regardless of their experience level.
                </p>
              </div>
              <div className="space-y-2">
                <h3 className="font-semibold">Share Quality Content</h3>
                <p className="text-sm text-muted-foreground">
                  Post well-researched guides, accurate information, and helpful resources.
                </p>
              </div>
              <div className="space-y-2">
                <h3 className="font-semibold">Help Newcomers</h3>
                <p className="text-sm text-muted-foreground">
                  Guide new members and answer questions constructively.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <CheckCircle className="w-5 h-5 mr-2 text-crypto-purple" />
                Content Guidelines
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h3 className="font-semibold mb-2">Testnet Posts</h3>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Include clear step-by-step instructions</li>
                    <li>• Verify testnet is still active</li>
                    <li>• Mention hardware/software requirements</li>
                    <li>• Add screenshots when helpful</li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Airdrop Posts</h3>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Verify legitimacy of the project</li>
                    <li>• Include eligibility criteria</li>
                    <li>• Mention deadlines and timelines</li>
                    <li>• Disclose any referral benefits</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <AlertTriangle className="w-5 h-5 mr-2 text-orange-500" />
                Reporting & Enforcement
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground">
                If you encounter content that violates these guidelines, please report it to our moderation team.
                Violations may result in warnings, temporary suspensions, or permanent bans depending on severity.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button variant="outline" className="flex-1">
                  Report Content
                </Button>
                <Button variant="outline" className="flex-1">
                  Contact Moderators
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}