import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Link } from "wouter";
import { 
  ArrowLeft, 
  Search, 
  Calendar,
  User,
  TrendingUp,
  Clock
} from "lucide-react";
import { useState } from "react";

export default function Blog() {
  const [searchQuery, setSearchQuery] = useState("");

  const blogPosts = [
    {
      id: 1,
      title: "The Future of Layer 2 Testnets: What to Expect in 2025",
      excerpt: "Explore the upcoming Layer 2 solutions and how they're revolutionizing testnet participation with lower costs and faster transactions.",
      author: "Alex Chen",
      date: "2024-12-28",
      readTime: "8 min read",
      category: "Technology",
      featured: true,
      image: "/api/placeholder/400/200"
    },
    {
      id: 2,
      title: "Airdrop Farming vs. Genuine Participation: Finding the Balance",
      excerpt: "A deep dive into sustainable airdrop strategies that benefit both projects and participants while maintaining ecosystem health.",
      author: "Sarah Rodriguez",
      date: "2024-12-25",
      readTime: "6 min read",
      category: "Strategy",
      featured: false,
      image: "/api/placeholder/400/200"
    },
    {
      id: 3,
      title: "Setting Up Multi-Chain Validator Infrastructure",
      excerpt: "Complete guide to building robust validator infrastructure that can handle multiple blockchain networks efficiently.",
      author: "Mike Johnson",
      date: "2024-12-22",
      readTime: "12 min read",
      category: "Technical",
      featured: true,
      image: "/api/placeholder/400/200"
    },
    {
      id: 4,
      title: "Community Building in DeFi: Lessons from Top Projects",
      excerpt: "How successful DeFi projects build and maintain engaged communities through effective social tasks and incentive programs.",
      author: "Emily Davis",
      date: "2024-12-20",
      readTime: "7 min read",
      category: "Community",
      featured: false,
      image: "/api/placeholder/400/200"
    },
    {
      id: 5,
      title: "Zero-Knowledge Proofs in Testnet Development",
      excerpt: "Understanding how ZK technology is being integrated into modern testnets and what it means for privacy and scalability.",
      author: "David Kim",
      date: "2024-12-18",
      readTime: "10 min read",
      category: "Technology",
      featured: false,
      image: "/api/placeholder/400/200"
    },
    {
      id: 6,
      title: "Risk Management for Crypto Testnet Participants",
      excerpt: "Essential security practices and risk mitigation strategies every testnet participant should know to protect their assets.",
      author: "Lisa Wang",
      date: "2024-12-15",
      readTime: "9 min read",
      category: "Security",
      featured: false,
      image: "/api/placeholder/400/200"
    }
  ];

  const filteredPosts = blogPosts.filter(post =>
    post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    post.excerpt.toLowerCase().includes(searchQuery.toLowerCase()) ||
    post.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const featuredPosts = filteredPosts.filter(post => post.featured);
  const regularPosts = filteredPosts.filter(post => !post.featured);

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "Technology": return "bg-crypto-blue/10 text-crypto-blue";
      case "Strategy": return "bg-crypto-emerald/10 text-crypto-emerald";
      case "Technical": return "bg-crypto-cyan/10 text-crypto-cyan";
      case "Community": return "bg-crypto-purple/10 text-crypto-purple";
      case "Security": return "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400";
      default: return "bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300";
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-6xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <Link href="/">
            <Button variant="ghost" className="mb-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </Link>
          <h1 className="text-3xl font-bold mb-4">CryptoHub Blog</h1>
          <p className="text-xl text-muted-foreground">
            Insights, tutorials, and news from the crypto community
          </p>
        </div>

        {/* Search Bar */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <div className="relative">
              <Input
                type="text"
                placeholder="Search blog posts..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
              <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>

        {/* Featured Posts */}
        {featuredPosts.length > 0 && (
          <div className="mb-12">
            <div className="flex items-center mb-6">
              <TrendingUp className="w-5 h-5 text-crypto-blue mr-2" />
              <h2 className="text-2xl font-bold">Featured Posts</h2>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {featuredPosts.map((post) => (
                <Card key={post.id} className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer">
                  <div className="aspect-video bg-muted"></div>
                  <CardHeader>
                    <div className="flex items-center gap-2 mb-2">
                      <Badge className={getCategoryColor(post.category)}>
                        {post.category}
                      </Badge>
                      <Badge variant="outline" className="bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300">
                        Featured
                      </Badge>
                    </div>
                    <CardTitle className="text-xl leading-tight">{post.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground mb-4 line-clamp-3">
                      {post.excerpt}
                    </p>
                    <div className="flex items-center justify-between text-sm text-muted-foreground">
                      <div className="flex items-center space-x-4">
                        <div className="flex items-center">
                          <User className="w-4 h-4 mr-1" />
                          {post.author}
                        </div>
                        <div className="flex items-center">
                          <Calendar className="w-4 h-4 mr-1" />
                          {new Date(post.date).toLocaleDateString()}
                        </div>
                      </div>
                      <div className="flex items-center">
                        <Clock className="w-4 h-4 mr-1" />
                        {post.readTime}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Regular Posts */}
        <div>
          <h2 className="text-2xl font-bold mb-6">Latest Posts</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {regularPosts.map((post) => (
              <Card key={post.id} className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer">
                <div className="aspect-video bg-muted"></div>
                <CardHeader>
                  <Badge className={`${getCategoryColor(post.category)} w-fit mb-2`}>
                    {post.category}
                  </Badge>
                  <CardTitle className="text-lg leading-tight">{post.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground text-sm mb-4 line-clamp-3">
                    {post.excerpt}
                  </p>
                  <div className="space-y-2 text-sm text-muted-foreground">
                    <div className="flex items-center">
                      <User className="w-4 h-4 mr-1" />
                      {post.author}
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <Calendar className="w-4 h-4 mr-1" />
                        {new Date(post.date).toLocaleDateString()}
                      </div>
                      <div className="flex items-center">
                        <Clock className="w-4 h-4 mr-1" />
                        {post.readTime}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {filteredPosts.length === 0 && (
          <Card className="mt-8">
            <CardContent className="text-center py-12">
              <Search className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium mb-2">No posts found</h3>
              <p className="text-muted-foreground">
                Try adjusting your search terms or browse all categories.
              </p>
            </CardContent>
          </Card>
        )}

        {/* Categories */}
        <div className="mt-12">
          <h2 className="text-2xl font-bold mb-6">Categories</h2>
          <div className="flex flex-wrap gap-3">
            {["Technology", "Strategy", "Technical", "Community", "Security"].map((category) => (
              <Button
                key={category}
                variant="outline"
                className="hover:shadow-md transition-shadow"
              >
                {category}
              </Button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}