import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Link } from "wouter";
import { 
  ArrowLeft, 
  Search, 
  BookOpen, 
  Clock, 
  Star,
  FlaskConical,
  Server,
  CheckSquare,
  Gift
} from "lucide-react";
import { useState } from "react";

export default function Tutorials() {
  const [searchQuery, setSearchQuery] = useState("");

  const tutorials = [
    {
      id: 1,
      title: "Getting Started with Testnet Participation",
      description: "Learn the basics of participating in blockchain testnets safely and effectively.",
      category: "Testnets",
      difficulty: "Beginner",
      duration: "15 min",
      rating: 4.8,
      icon: FlaskConical,
      color: "crypto-blue"
    },
    {
      id: 2,
      title: "Setting Up Your First Validator Node",
      description: "Complete guide to setting up and running a validator node for various networks.",
      category: "Node Setup",
      difficulty: "Intermediate",
      duration: "45 min",
      rating: 4.9,
      icon: Server,
      color: "crypto-cyan"
    },
    {
      id: 3,
      title: "Maximizing Airdrop Opportunities",
      description: "Strategies and best practices for qualifying for cryptocurrency airdrops.",
      category: "Airdrops",
      difficulty: "Beginner",
      duration: "20 min",
      rating: 4.7,
      icon: Gift,
      color: "crypto-purple"
    },
    {
      id: 4,
      title: "Social Tasks and Community Engagement",
      description: "How to effectively complete social tasks while building genuine community connections.",
      category: "Social Tasks",
      difficulty: "Beginner",
      duration: "10 min",
      rating: 4.6,
      icon: CheckSquare,
      color: "crypto-emerald"
    },
    {
      id: 5,
      title: "Advanced Testnet Strategies",
      description: "Advanced techniques for identifying high-value testnet opportunities early.",
      category: "Testnets",
      difficulty: "Advanced",
      duration: "30 min",
      rating: 4.8,
      icon: FlaskConical,
      color: "crypto-blue"
    },
    {
      id: 6,
      title: "RPC Node Configuration and Management",
      description: "Learn to configure and manage RPC nodes for optimal performance and reliability.",
      category: "Node Setup",
      difficulty: "Advanced",
      duration: "60 min",
      rating: 4.9,
      icon: Server,
      color: "crypto-cyan"
    }
  ];

  const filteredTutorials = tutorials.filter(tutorial =>
    tutorial.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    tutorial.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
    tutorial.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Beginner": return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300";
      case "Intermediate": return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300";
      case "Advanced": return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300";
      default: return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300";
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-6xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <Link href="/">
            <Button variant="ghost" className="mb-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </Link>
          <h1 className="text-3xl font-bold mb-4">Tutorials & Guides</h1>
          <p className="text-xl text-muted-foreground">
            Learn everything you need to know about crypto testnets and airdrops
          </p>
        </div>

        {/* Search Bar */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <div className="relative">
              <Input
                type="text"
                placeholder="Search tutorials by title, description, or category..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
              <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>

        {/* Tutorial Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTutorials.map((tutorial) => {
            const IconComponent = tutorial.icon;
            return (
              <Card key={tutorial.id} className="hover:shadow-lg transition-shadow cursor-pointer">
                <CardHeader>
                  <div className="flex items-start justify-between mb-2">
                    <div className={`w-10 h-10 bg-${tutorial.color}/10 rounded-lg flex items-center justify-center`}>
                      <IconComponent className={`w-5 h-5 text-${tutorial.color}`} />
                    </div>
                    <div className="flex items-center space-x-1">
                      <Star className="w-4 h-4 text-yellow-500 fill-current" />
                      <span className="text-sm font-medium">{tutorial.rating}</span>
                    </div>
                  </div>
                  <CardTitle className="text-lg leading-tight">{tutorial.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground text-sm mb-4 line-clamp-2">
                    {tutorial.description}
                  </p>
                  
                  <div className="flex flex-wrap gap-2 mb-4">
                    <Badge variant="outline" className="text-xs">
                      {tutorial.category}
                    </Badge>
                    <Badge className={`text-xs ${getDifficultyColor(tutorial.difficulty)}`}>
                      {tutorial.difficulty}
                    </Badge>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center text-sm text-muted-foreground">
                      <Clock className="w-4 h-4 mr-1" />
                      {tutorial.duration}
                    </div>
                    <Button size="sm" variant="outline">
                      <BookOpen className="w-4 h-4 mr-2" />
                      Start
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {filteredTutorials.length === 0 && (
          <Card className="mt-8">
            <CardContent className="text-center py-12">
              <BookOpen className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium mb-2">No tutorials found</h3>
              <p className="text-muted-foreground">
                Try adjusting your search terms or browse all categories.
              </p>
            </CardContent>
          </Card>
        )}

        {/* Categories Overview */}
        <div className="mt-12">
          <h2 className="text-2xl font-bold mb-6">Popular Categories</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="text-center p-6 hover:shadow-lg transition-shadow cursor-pointer">
              <FlaskConical className="w-8 h-8 text-crypto-blue mx-auto mb-3" />
              <h3 className="font-semibold mb-1">Testnets</h3>
              <p className="text-sm text-muted-foreground">12 tutorials</p>
            </Card>
            <Card className="text-center p-6 hover:shadow-lg transition-shadow cursor-pointer">
              <Server className="w-8 h-8 text-crypto-cyan mx-auto mb-3" />
              <h3 className="font-semibold mb-1">Node Setup</h3>
              <p className="text-sm text-muted-foreground">8 tutorials</p>
            </Card>
            <Card className="text-center p-6 hover:shadow-lg transition-shadow cursor-pointer">
              <CheckSquare className="w-8 h-8 text-crypto-emerald mx-auto mb-3" />
              <h3 className="font-semibold mb-1">Social Tasks</h3>
              <p className="text-sm text-muted-foreground">6 tutorials</p>
            </Card>
            <Card className="text-center p-6 hover:shadow-lg transition-shadow cursor-pointer">
              <Gift className="w-8 h-8 text-crypto-purple mx-auto mb-3" />
              <h3 className="font-semibold mb-1">Airdrops</h3>
              <p className="text-sm text-muted-foreground">15 tutorials</p>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}