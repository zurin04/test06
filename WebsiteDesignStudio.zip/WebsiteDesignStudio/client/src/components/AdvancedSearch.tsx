import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Calendar } from "@/components/ui/calendar";
import { CalendarIcon, Filter, X, Search, TrendingUp, Clock, Heart } from "lucide-react";
import { format } from "date-fns";

interface SearchFilters {
  query: string;
  category: string;
  sortBy: 'recent' | 'popular' | 'trending';
  timeRange: 'all' | 'day' | 'week' | 'month' | 'year';
  minLikes?: number;
  dateFrom?: Date;
  dateTo?: Date;
  tags?: string[];
}

interface AdvancedSearchProps {
  onSearch: (filters: SearchFilters) => void;
  initialFilters?: Partial<SearchFilters>;
}

const categories = [
  { value: '', label: 'All Categories' },
  { value: 'testnet', label: 'Testnets' },
  { value: 'node-setup', label: 'Node Setup' },
  { value: 'social-tasks', label: 'Social Tasks' },
  { value: 'airdrops', label: 'Airdrops' },
];

const sortOptions = [
  { value: 'recent', label: 'Most Recent', icon: Clock },
  { value: 'popular', label: 'Most Popular', icon: Heart },
  { value: 'trending', label: 'Trending', icon: TrendingUp },
];

const timeRanges = [
  { value: 'all', label: 'All Time' },
  { value: 'day', label: 'Last 24 Hours' },
  { value: 'week', label: 'Last Week' },
  { value: 'month', label: 'Last Month' },
  { value: 'year', label: 'Last Year' },
];

export default function AdvancedSearch({ onSearch, initialFilters = {} }: AdvancedSearchProps) {
  const [filters, setFilters] = useState<SearchFilters>({
    query: '',
    category: '',
    sortBy: 'recent',
    timeRange: 'all',
    ...initialFilters,
  });

  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [tempDateFrom, setTempDateFrom] = useState<Date | undefined>(filters.dateFrom);
  const [tempDateTo, setTempDateTo] = useState<Date | undefined>(filters.dateTo);

  // Get popular tags for suggestions
  const { data: popularTags = [] } = useQuery({
    queryKey: ['/api/tags/popular'],
    queryFn: async () => {
      const response = await fetch('/api/tags/popular', {
        credentials: 'include'
      });
      
      if (!response.ok) {
        return [];
      }
      
      return response.json() as Promise<string[]>;
    },
  });

  const handleFilterChange = (key: keyof SearchFilters, value: any) => {
    const newFilters = { ...filters, [key]: value };
    setFilters(newFilters);
  };

  const handleSearch = () => {
    onSearch(filters);
    setIsFilterOpen(false);
  };

  const clearFilters = () => {
    const clearedFilters: SearchFilters = {
      query: '',
      category: '',
      sortBy: 'recent',
      timeRange: 'all',
    };
    setFilters(clearedFilters);
    onSearch(clearedFilters);
  };

  const addTag = (tag: string) => {
    if (!filters.tags?.includes(tag)) {
      handleFilterChange('tags', [...(filters.tags || []), tag]);
    }
  };

  const removeTag = (tag: string) => {
    handleFilterChange('tags', filters.tags?.filter(t => t !== tag) || []);
  };

  const hasActiveFilters = 
    filters.category || 
    filters.timeRange !== 'all' || 
    filters.minLikes || 
    filters.dateFrom || 
    filters.dateTo || 
    (filters.tags && filters.tags.length > 0);

  return (
    <div className="w-full space-y-4">
      {/* Quick Search Bar */}
      <div className="flex gap-2">
        <div className="flex-1 relative">
          <Input
            type="text"
            placeholder="Search testnets, guides, airdrops..."
            value={filters.query}
            onChange={(e) => handleFilterChange('query', e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
            className="pl-10"
          />
          <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
        </div>

        {/* Sort Selector */}
        <Select 
          value={filters.sortBy} 
          onValueChange={(value) => handleFilterChange('sortBy', value as any)}
        >
          <SelectTrigger className="w-40">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {sortOptions.map(option => {
              const Icon = option.icon;
              return (
                <SelectItem key={option.value} value={option.value}>
                  <div className="flex items-center space-x-2">
                    <Icon className="w-4 h-4" />
                    <span>{option.label}</span>
                  </div>
                </SelectItem>
              );
            })}
          </SelectContent>
        </Select>

        {/* Advanced Filters */}
        <Popover open={isFilterOpen} onOpenChange={setIsFilterOpen}>
          <PopoverTrigger asChild>
            <Button variant="outline" className="relative">
              <Filter className="w-4 h-4 mr-2" />
              Filters
              {hasActiveFilters && (
                <Badge className="absolute -top-1 -right-1 w-2 h-2 p-0 bg-blue-500" />
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-80 p-0" align="end">
            <Card className="border-0 shadow-lg">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">Advanced Filters</CardTitle>
                  {hasActiveFilters && (
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={clearFilters}
                      className="text-xs"
                    >
                      <X className="w-3 h-3 mr-1" />
                      Clear All
                    </Button>
                  )}
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Category Filter */}
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Category</Label>
                  <Select 
                    value={filters.category} 
                    onValueChange={(value) => handleFilterChange('category', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map(category => (
                        <SelectItem key={category.value} value={category.value}>
                          {category.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Time Range Filter */}
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Time Range</Label>
                  <Select 
                    value={filters.timeRange} 
                    onValueChange={(value) => handleFilterChange('timeRange', value as any)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {timeRanges.map(range => (
                        <SelectItem key={range.value} value={range.value}>
                          {range.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Minimum Likes Filter */}
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Minimum Likes</Label>
                  <Input
                    type="number"
                    placeholder="e.g. 10"
                    min="0"
                    value={filters.minLikes || ''}
                    onChange={(e) => handleFilterChange('minLikes', e.target.value ? parseInt(e.target.value) : undefined)}
                  />
                </div>

                {/* Custom Date Range */}
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Custom Date Range</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="outline" className="justify-start text-left font-normal">
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {tempDateFrom ? format(tempDateFrom, "PPP") : "From"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={tempDateFrom}
                          onSelect={(date) => {
                            setTempDateFrom(date);
                            handleFilterChange('dateFrom', date);
                          }}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>

                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="outline" className="justify-start text-left font-normal">
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {tempDateTo ? format(tempDateTo, "PPP") : "To"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={tempDateTo}
                          onSelect={(date) => {
                            setTempDateTo(date);
                            handleFilterChange('dateTo', date);
                          }}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>

                {/* Tags Filter */}
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Tags</Label>
                  {filters.tags && filters.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1 mb-2">
                      {filters.tags.map(tag => (
                        <Badge 
                          key={tag} 
                          variant="secondary" 
                          className="cursor-pointer"
                          onClick={() => removeTag(tag)}
                        >
                          {tag}
                          <X className="w-3 h-3 ml-1" />
                        </Badge>
                      ))}
                    </div>
                  )}
                  
                  {popularTags.length > 0 && (
                    <div className="space-y-2">
                      <p className="text-xs text-muted-foreground">Popular tags:</p>
                      <div className="flex flex-wrap gap-1">
                        {popularTags.slice(0, 10).map(tag => (
                          <Badge 
                            key={tag}
                            variant="outline" 
                            className="cursor-pointer hover:bg-primary hover:text-primary-foreground"
                            onClick={() => addTag(tag)}
                          >
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                <Separator />

                {/* Action Buttons */}
                <div className="flex gap-2">
                  <Button onClick={handleSearch} className="flex-1">
                    <Search className="w-4 h-4 mr-2" />
                    Apply Filters
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={() => setIsFilterOpen(false)}
                  >
                    Cancel
                  </Button>
                </div>
              </CardContent>
            </Card>
          </PopoverContent>
        </Popover>

        <Button onClick={handleSearch}>
          <Search className="w-4 h-4" />
        </Button>
      </div>

      {/* Active Filters Display */}
      {hasActiveFilters && (
        <div className="flex flex-wrap gap-2 items-center">
          <span className="text-sm text-muted-foreground">Active filters:</span>
          
          {filters.category && (
            <Badge variant="secondary" className="cursor-pointer" onClick={() => handleFilterChange('category', '')}>
              Category: {categories.find(c => c.value === filters.category)?.label}
              <X className="w-3 h-3 ml-1" />
            </Badge>
          )}
          
          {filters.timeRange !== 'all' && (
            <Badge variant="secondary" className="cursor-pointer" onClick={() => handleFilterChange('timeRange', 'all')}>
              {timeRanges.find(t => t.value === filters.timeRange)?.label}
              <X className="w-3 h-3 ml-1" />
            </Badge>
          )}
          
          {filters.minLikes && (
            <Badge variant="secondary" className="cursor-pointer" onClick={() => handleFilterChange('minLikes', undefined)}>
              Min likes: {filters.minLikes}
              <X className="w-3 h-3 ml-1" />
            </Badge>
          )}

          {filters.tags?.map(tag => (
            <Badge key={tag} variant="secondary" className="cursor-pointer" onClick={() => removeTag(tag)}>
              {tag}
              <X className="w-3 h-3 ml-1" />
            </Badge>
          ))}
        </div>
      )}
    </div>
  );
}