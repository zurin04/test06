import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  FlaskConical, 
  Server, 
  CheckSquare, 
  Gift,
  Plus,
  TrendingUp
} from "lucide-react";
import { cn } from "@/lib/utils";

interface SidebarProps {
  onCreatePost?: () => void;
  selectedCategory: string;
  onCategoryChange: (category: string) => void;
}

const categories = [
  {
    id: 'testnets',
    label: 'Testnets',
    icon: FlaskConical,
    color: 'bg-crypto-blue text-white',
    hoverColor: 'hover:bg-crypto-blue/10 hover:text-crypto-blue',
  },
  {
    id: 'node-setup',
    label: 'Node Setup',
    icon: Server,
    color: 'bg-crypto-cyan text-white',
    hoverColor: 'hover:bg-crypto-cyan/10 hover:text-crypto-cyan',
  },
  {
    id: 'social-tasks',
    label: 'Social Tasks',
    icon: CheckSquare,
    color: 'bg-crypto-emerald text-white',
    hoverColor: 'hover:bg-crypto-emerald/10 hover:text-crypto-emerald',
  },
  {
    id: 'airdrops',
    label: 'Airdrops',
    icon: Gift,
    color: 'bg-crypto-purple text-white',
    hoverColor: 'hover:bg-crypto-purple/10 hover:text-crypto-purple',
  },
];

const trendingTopics = [
  { name: '#StarkNet', color: 'bg-crypto-blue' },
  { name: '#LayerZero', color: 'bg-crypto-purple' },
  { name: '#Arbitrum', color: 'bg-crypto-cyan' },
  { name: '#zkSync', color: 'bg-crypto-emerald' },
  { name: '#Polygon', color: 'bg-crypto-blue' },
];

export default function Sidebar({ onCreatePost, selectedCategory, onCategoryChange }: SidebarProps) {
  // Mock category counts - in real app, fetch from API
  const categoryCounts = {
    testnets: 234,
    'node-setup': 156,
    'social-tasks': 89,
    airdrops: 67,
  };

  return (
    <div className="lg:col-span-1 space-y-6">
      {/* Create Post Button */}
      {onCreatePost && (
        <Button 
          onClick={onCreatePost}
          className="w-full bg-crypto-gradient hover:opacity-90 text-white py-3 px-4 rounded-xl font-semibold hover:shadow-lg transform hover:scale-105 transition-all duration-300"
        >
          <Plus className="w-4 h-4 mr-2" />
          Create Post
        </Button>
      )}

      {/* Categories */}
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-lg">Categories</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {/* All Categories */}
          <button
            onClick={() => onCategoryChange('')}
            className={cn(
              "w-full flex items-center justify-between p-3 rounded-lg transition-all duration-300",
              selectedCategory === '' 
                ? 'bg-primary text-primary-foreground' 
                : 'hover:bg-muted'
            )}
          >
            <div className="flex items-center space-x-3">
              <TrendingUp className="w-4 h-4" />
              <span>All Posts</span>
            </div>
          </button>

          {categories.map((category) => {
            const Icon = category.icon;
            const isSelected = selectedCategory === category.id;
            const count = categoryCounts[category.id as keyof typeof categoryCounts] || 0;

            return (
              <button
                key={category.id}
                onClick={() => onCategoryChange(category.id)}
                className={cn(
                  "w-full flex items-center justify-between p-3 rounded-lg transition-all duration-300",
                  isSelected ? category.color : category.hoverColor
                )}
              >
                <div className="flex items-center space-x-3">
                  <Icon className="w-4 h-4" />
                  <span>{category.label}</span>
                </div>
                <Badge 
                  variant={isSelected ? "secondary" : "default"}
                  className={cn(
                    "text-xs",
                    isSelected ? "bg-white/20" : "bg-muted"
                  )}
                >
                  {count}
                </Badge>
              </button>
            );
          })}
        </CardContent>
      </Card>

      {/* Trending Topics */}
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-lg flex items-center">
            🔥 Trending
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {trendingTopics.map((topic, index) => (
            <div key={index} className="flex items-center space-x-3">
              <div className={cn("w-2 h-2 rounded-full", topic.color)} />
              <span className="text-sm font-medium">{topic.name}</span>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Community Stats */}
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-lg">Community Stats</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">Active Users</span>
            <span className="font-semibold text-crypto-blue">10,234</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">Posts Today</span>
            <span className="font-semibold text-crypto-purple">156</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">Total Rewards</span>
            <span className="font-semibold text-crypto-emerald">$2.1M</span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
