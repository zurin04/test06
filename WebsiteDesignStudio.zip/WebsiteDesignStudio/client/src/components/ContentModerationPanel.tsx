import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Shield, 
  Eye, 
  EyeOff, 
  Trash2, 
  Flag, 
  MessageSquare, 
  User,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Clock,
  Search
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import type { PostWithDetails, User, Comment } from "@shared/schema";

interface ModerationAction {
  id: number;
  type: 'hide' | 'delete' | 'warn' | 'restore';
  reason: string;
  postId?: number;
  userId?: string;
  moderatorId: string;
  createdAt: string;
}

interface ReportedContent {
  id: number;
  type: 'post' | 'comment' | 'user';
  contentId: string;
  reporterId: string;
  reason: string;
  status: 'pending' | 'reviewed' | 'resolved';
  createdAt: string;
  content?: PostWithDetails | Comment | User;
}

export default function ContentModerationPanel() {
  const [selectedTab, setSelectedTab] = useState("posts");
  const [actionDialog, setActionDialog] = useState<{
    isOpen: boolean;
    type: 'hide' | 'delete' | 'warn' | null;
    content?: any;
  }>({ isOpen: false, type: null });
  const [moderationReason, setModerationReason] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch reported content
  const { data: reportedContent = [], isLoading: reportsLoading } = useQuery({
    queryKey: ['/api/admin/reports'],
    queryFn: async () => {
      const response = await fetch('/api/admin/reports', {
        credentials: 'include'
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch reports');
      }
      
      return response.json() as Promise<ReportedContent[]>;
    },
  });

  // Fetch flagged posts
  const { data: flaggedPosts = [], isLoading: postsLoading } = useQuery({
    queryKey: ['/api/admin/flagged-posts'],
    queryFn: async () => {
      const response = await fetch('/api/admin/flagged-posts', {
        credentials: 'include'
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch flagged posts');
      }
      
      return response.json() as Promise<PostWithDetails[]>;
    },
  });

  // Fetch recent moderation actions
  const { data: moderationHistory = [], isLoading: historyLoading } = useQuery({
    queryKey: ['/api/admin/moderation-history'],
    queryFn: async () => {
      const response = await fetch('/api/admin/moderation-history', {
        credentials: 'include'
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch moderation history');
      }
      
      return response.json() as Promise<ModerationAction[]>;
    },
  });

  // Moderation action mutations
  const moderateContentMutation = useMutation({
    mutationFn: async ({ 
      action, 
      contentType, 
      contentId, 
      reason 
    }: {
      action: string;
      contentType: string;
      contentId: string;
      reason: string;
    }) => {
      const response = await fetch('/api/admin/moderate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({
          action,
          contentType,
          contentId,
          reason,
        }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to moderate content');
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/reports'] });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/flagged-posts'] });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/moderation-history'] });
      setActionDialog({ isOpen: false, type: null });
      setModerationReason("");
      toast({
        title: "Action completed",
        description: "Moderation action has been applied successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Action failed",
        description: error.message,
      });
    },
  });

  const handleModerationAction = (type: 'hide' | 'delete' | 'warn', content: any) => {
    setActionDialog({
      isOpen: true,
      type,
      content,
    });
  };

  const confirmModerationAction = () => {
    if (!actionDialog.content || !actionDialog.type || !moderationReason.trim()) {
      toast({
        variant: "destructive",
        title: "Missing information",
        description: "Please provide a reason for this action.",
      });
      return;
    }

    moderateContentMutation.mutate({
      action: actionDialog.type,
      contentType: actionDialog.content.title ? 'post' : 'comment',
      contentId: actionDialog.content.id.toString(),
      reason: moderationReason,
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800 border-yellow-300';
      case 'reviewed':
        return 'bg-blue-100 text-blue-800 border-blue-300';
      case 'resolved':
        return 'bg-green-100 text-green-800 border-green-300';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-300';
    }
  };

  const getActionIcon = (action: string) => {
    switch (action) {
      case 'hide':
        return <EyeOff className="w-4 h-4" />;
      case 'delete':
        return <Trash2 className="w-4 h-4" />;
      case 'warn':
        return <AlertTriangle className="w-4 h-4" />;
      case 'restore':
        return <CheckCircle className="w-4 h-4" />;
      default:
        return <Shield className="w-4 h-4" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Content Moderation</h2>
        <div className="flex items-center space-x-2">
          <Input
            placeholder="Search content..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-64"
          />
          <Button variant="outline" size="sm">
            <Search className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <Tabs value={selectedTab} onValueChange={setSelectedTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="reports">
            <Flag className="w-4 h-4 mr-2" />
            Reports ({reportedContent.length})
          </TabsTrigger>
          <TabsTrigger value="posts">
            <MessageSquare className="w-4 h-4 mr-2" />
            Flagged Posts ({flaggedPosts.length})
          </TabsTrigger>
          <TabsTrigger value="users">
            <User className="w-4 h-4 mr-2" />
            User Actions
          </TabsTrigger>
          <TabsTrigger value="history">
            <Clock className="w-4 h-4 mr-2" />
            History
          </TabsTrigger>
        </TabsList>

        {/* Reports Tab */}
        <TabsContent value="reports">
          <Card>
            <CardHeader>
              <CardTitle>Reported Content</CardTitle>
            </CardHeader>
            <CardContent>
              {reportsLoading ? (
                <p>Loading reports...</p>
              ) : reportedContent.length === 0 ? (
                <Alert>
                  <CheckCircle className="h-4 w-4" />
                  <AlertDescription>
                    No pending reports. Great job keeping the community clean!
                  </AlertDescription>
                </Alert>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Type</TableHead>
                      <TableHead>Content</TableHead>
                      <TableHead>Reason</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Reported</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {reportedContent.map((report) => (
                      <TableRow key={report.id}>
                        <TableCell>
                          <Badge variant="outline">{report.type}</Badge>
                        </TableCell>
                        <TableCell className="max-w-xs">
                          <div className="truncate">
                            {report.type === 'post' && (report.content as any)?.title}
                            {report.type === 'comment' && (report.content as any)?.content}
                            {report.type === 'user' && (report.content as any)?.email}
                          </div>
                        </TableCell>
                        <TableCell>{report.reason}</TableCell>
                        <TableCell>
                          <Badge className={getStatusColor(report.status)}>
                            {report.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {formatDistanceToNow(new Date(report.createdAt), { addSuffix: true })}
                        </TableCell>
                        <TableCell>
                          <div className="flex space-x-1">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleModerationAction('hide', report.content)}
                            >
                              <EyeOff className="w-3 h-3" />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleModerationAction('warn', report.content)}
                            >
                              <AlertTriangle className="w-3 h-3" />
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => handleModerationAction('delete', report.content)}
                            >
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Flagged Posts Tab */}
        <TabsContent value="posts">
          <Card>
            <CardHeader>
              <CardTitle>Flagged Posts</CardTitle>
            </CardHeader>
            <CardContent>
              {postsLoading ? (
                <p>Loading flagged posts...</p>
              ) : flaggedPosts.length === 0 ? (
                <Alert>
                  <CheckCircle className="h-4 w-4" />
                  <AlertDescription>
                    No flagged posts requiring attention.
                  </AlertDescription>
                </Alert>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Title</TableHead>
                      <TableHead>Author</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Created</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {flaggedPosts.map((post) => (
                      <TableRow key={post.id}>
                        <TableCell className="max-w-xs">
                          <div className="truncate font-medium">{post.title}</div>
                        </TableCell>
                        <TableCell>{(post.user as any)?.firstName || 'Unknown'}</TableCell>
                        <TableCell>
                          <Badge variant="secondary">{post.category}</Badge>
                        </TableCell>
                        <TableCell>
                          {formatDistanceToNow(new Date(post.createdAt), { addSuffix: true })}
                        </TableCell>
                        <TableCell>
                          <div className="flex space-x-1">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleModerationAction('hide', post)}
                            >
                              <EyeOff className="w-3 h-3" />
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => handleModerationAction('delete', post)}
                            >
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Moderation History Tab */}
        <TabsContent value="history">
          <Card>
            <CardHeader>
              <CardTitle>Moderation History</CardTitle>
            </CardHeader>
            <CardContent>
              {historyLoading ? (
                <p>Loading history...</p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Action</TableHead>
                      <TableHead>Content</TableHead>
                      <TableHead>Reason</TableHead>
                      <TableHead>Moderator</TableHead>
                      <TableHead>Date</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {moderationHistory.map((action) => (
                      <TableRow key={action.id}>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            {getActionIcon(action.type)}
                            <span className="capitalize">{action.type}</span>
                          </div>
                        </TableCell>
                        <TableCell>Post #{action.postId || 'N/A'}</TableCell>
                        <TableCell className="max-w-xs truncate">{action.reason}</TableCell>
                        <TableCell>{action.moderatorId}</TableCell>
                        <TableCell>
                          {formatDistanceToNow(new Date(action.createdAt), { addSuffix: true })}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Moderation Action Dialog */}
      <Dialog open={actionDialog.isOpen} onOpenChange={(open) => 
        setActionDialog({ ...actionDialog, isOpen: open })
      }>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {actionDialog.type === 'hide' && 'Hide Content'}
              {actionDialog.type === 'delete' && 'Delete Content'}
              {actionDialog.type === 'warn' && 'Issue Warning'}
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <div>
              <p className="text-sm text-muted-foreground mb-2">
                You are about to {actionDialog.type} the following content:
              </p>
              <div className="p-3 bg-muted rounded-md">
                <p className="font-medium">
                  {actionDialog.content?.title || actionDialog.content?.content || 'Content'}
                </p>
              </div>
            </div>
            
            <div>
              <label className="text-sm font-medium">Reason for action:</label>
              <Textarea
                placeholder="Explain why this action is being taken..."
                value={moderationReason}
                onChange={(e) => setModerationReason(e.target.value)}
                className="mt-2"
              />
            </div>
            
            <div className="flex justify-end space-x-2">
              <Button 
                variant="outline" 
                onClick={() => setActionDialog({ isOpen: false, type: null })}
              >
                Cancel
              </Button>
              <Button 
                variant={actionDialog.type === 'delete' ? 'destructive' : 'default'}
                onClick={confirmModerationAction}
                disabled={moderateContentMutation.isPending}
              >
                {moderateContentMutation.isPending ? 'Processing...' : `Confirm ${actionDialog.type}`}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}