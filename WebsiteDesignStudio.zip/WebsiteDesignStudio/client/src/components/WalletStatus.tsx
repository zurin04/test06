import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Wallet, Check, AlertCircle, Copy } from "lucide-react";

interface WalletStatusProps {
  walletAddress?: string;
  onWalletConnect?: (address: string) => void;
}

export default function WalletStatus({ walletAddress, onWalletConnect }: WalletStatusProps) {
  const [isConnected, setIsConnected] = useState(false);
  const [currentAddress, setCurrentAddress] = useState<string>("");
  const [isConnecting, setIsConnecting] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (walletAddress) {
      setCurrentAddress(walletAddress);
      setIsConnected(true);
    }
    
    // Check if wallet is already connected
    checkWalletConnection();
  }, [walletAddress]);

  const checkWalletConnection = async () => {
    if (window.ethereum) {
      try {
        const accounts = await window.ethereum.request({ method: 'eth_accounts' });
        if (accounts.length > 0) {
          setCurrentAddress(accounts[0]);
          setIsConnected(true);
        }
      } catch (error) {
        console.error("Error checking wallet connection:", error);
      }
    }
  };

  const connectWallet = async () => {
    if (!window.ethereum) {
      toast({
        title: "MetaMask not found",
        description: "Please install MetaMask to connect your wallet.",
        variant: "destructive",
      });
      return;
    }

    setIsConnecting(true);

    try {
      const accounts = await window.ethereum.request({
        method: 'eth_requestAccounts'
      });

      if (accounts.length > 0) {
        const address = accounts[0];
        setCurrentAddress(address);
        setIsConnected(true);
        
        if (onWalletConnect) {
          onWalletConnect(address);
        }

        toast({
          title: "Wallet connected",
          description: "Your MetaMask wallet has been connected successfully.",
        });
      }
    } catch (error: any) {
      toast({
        title: "Connection failed",
        description: error.message || "Failed to connect wallet.",
        variant: "destructive",
      });
    } finally {
      setIsConnecting(false);
    }
  };

  const copyAddress = () => {
    if (currentAddress) {
      navigator.clipboard.writeText(currentAddress);
      toast({
        title: "Address copied",
        description: "Wallet address copied to clipboard.",
      });
    }
  };

  const formatAddress = (address: string) => {
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
  };

  return (
    <Card className="w-full">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
              isConnected ? 'bg-green-100 dark:bg-green-900' : 'bg-gray-100 dark:bg-gray-800'
            }`}>
              {isConnected ? (
                <Check className="w-5 h-5 text-green-600" />
              ) : (
                <Wallet className="w-5 h-5 text-gray-600" />
              )}
            </div>
            
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="font-medium">Wallet Status</h3>
                <Badge variant={isConnected ? "default" : "secondary"}>
                  {isConnected ? "Connected" : "Not Connected"}
                </Badge>
              </div>
              
              {isConnected && currentAddress ? (
                <div className="flex items-center space-x-2 mt-1">
                  <span className="text-sm text-muted-foreground font-mono">
                    {formatAddress(currentAddress)}
                  </span>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={copyAddress}
                    className="h-6 w-6 p-0"
                  >
                    <Copy className="w-3 h-3" />
                  </Button>
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">
                  Connect your wallet for Web3 features
                </p>
              )}
            </div>
          </div>

          {!isConnected && (
            <Button
              onClick={connectWallet}
              disabled={isConnecting}
              size="sm"
              className="bg-crypto-gradient hover:opacity-90"
            >
              {isConnecting ? "Connecting..." : "Connect"}
            </Button>
          )}
        </div>

        {!window.ethereum && (
          <div className="mt-3 p-3 bg-orange-50 dark:bg-orange-900/20 border border-orange-200 dark:border-orange-800 rounded-lg">
            <div className="flex items-center space-x-2">
              <AlertCircle className="w-4 h-4 text-orange-600" />
              <span className="text-sm text-orange-700 dark:text-orange-300">
                MetaMask not detected. 
                <a 
                  href="https://metamask.io/download/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="underline ml-1"
                >
                  Install MetaMask
                </a>
              </span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}