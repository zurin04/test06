import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { X, Megaphone } from "lucide-react";
import { cn } from "@/lib/utils";
import type { Announcement } from "@shared/schema";

export default function AnnouncementBanner() {
  const [dismissedAnnouncements, setDismissedAnnouncements] = useState<Set<number>>(
    new Set(JSON.parse(localStorage.getItem('dismissedAnnouncements') || '[]'))
  );

  const { data: announcements = [] } = useQuery({
    queryKey: ['/api/announcements'],
    queryFn: async () => {
      const response = await fetch('/api/announcements', {
        credentials: 'include'
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch announcements');
      }
      
      return response.json() as Promise<Announcement[]>;
    },
    retry: false,
  });

  const activeAnnouncements = announcements.filter(
    announcement => !dismissedAnnouncements.has(announcement.id)
  );

  const dismissAnnouncement = (announcementId: number) => {
    const newDismissed = new Set(dismissedAnnouncements);
    newDismissed.add(announcementId);
    setDismissedAnnouncements(newDismissed);
    localStorage.setItem('dismissedAnnouncements', JSON.stringify([...newDismissed]));
  };

  if (activeAnnouncements.length === 0) {
    return null;
  }

  // Show the most recent announcement
  const announcement = activeAnnouncements[0];

  return (
    <div className="bg-crypto-gradient text-white py-3 border-b">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3 flex-1 min-w-0">
            <Megaphone className="w-5 h-5 flex-shrink-0" />
            <div className="flex-1 min-w-0">
              <h4 className="font-semibold text-sm">{announcement.title}</h4>
              <p className="text-sm opacity-90 line-clamp-2">{announcement.content}</p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => dismissAnnouncement(announcement.id)}
            className="text-white hover:text-gray-200 hover:bg-white/10 ml-4 flex-shrink-0"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
