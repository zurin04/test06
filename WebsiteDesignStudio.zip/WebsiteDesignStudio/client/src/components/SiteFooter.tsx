import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { FlaskConical, Twitter, MessageCircle, Send, Github } from "lucide-react";

interface SiteSettings {
  site_name?: string;
  twitter_url?: string;
  discord_url?: string;
  telegram_url?: string;
  github_url?: string;
}

export default function SiteFooter() {
  const { data: settings } = useQuery<Record<string, string>>({
    queryKey: ["/api/settings"],
    retry: false,
  });

  const siteSettings: SiteSettings = {
    site_name: settings?.site_name || "CryptoHub",
    twitter_url: settings?.twitter_url || "",
    discord_url: settings?.discord_url || "",
    telegram_url: settings?.telegram_url || "",
    github_url: settings?.github_url || "",
  };

  return (
    <footer className="border-t bg-background/80 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center mb-4">
              <div className="w-8 h-8 bg-crypto-gradient rounded-lg flex items-center justify-center mr-3">
                <FlaskConical className="w-4 h-4 text-white" />
              </div>
              <h3 className="text-lg font-bold text-crypto-gradient">{siteSettings.site_name}</h3>
            </div>
            <p className="text-muted-foreground text-sm">
              The ultimate community platform for cryptocurrency testnets, node setups, and airdrop opportunities.
            </p>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Community</h4>
            <div className="space-y-2 text-sm text-muted-foreground">
              <Link href="/guidelines" className="block hover:text-crypto-blue transition-colors">Guidelines</Link>
              <Link href="/faq" className="block hover:text-crypto-blue transition-colors">FAQ</Link>
              <Link href="/support" className="block hover:text-crypto-blue transition-colors">Support</Link>
            </div>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Resources</h4>
            <div className="space-y-2 text-sm text-muted-foreground">
              <Link href="/api-docs" className="block hover:text-crypto-blue transition-colors">API Documentation</Link>
              <Link href="/tutorials" className="block hover:text-crypto-blue transition-colors">Tutorials</Link>
              <Link href="/blog" className="block hover:text-crypto-blue transition-colors">Blog</Link>
            </div>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Connect</h4>
            <div className="flex space-x-4">
              {siteSettings.twitter_url && (
                <a 
                  href={siteSettings.twitter_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-muted-foreground hover:text-crypto-blue transition-colors"
                  aria-label="Twitter"
                >
                  <Twitter className="w-5 h-5" />
                </a>
              )}
              {siteSettings.discord_url && (
                <a 
                  href={siteSettings.discord_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-muted-foreground hover:text-crypto-blue transition-colors"
                  aria-label="Discord"
                >
                  <MessageCircle className="w-5 h-5" />
                </a>
              )}
              {siteSettings.telegram_url && (
                <a 
                  href={siteSettings.telegram_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-muted-foreground hover:text-crypto-blue transition-colors"
                  aria-label="Telegram"
                >
                  <Send className="w-5 h-5" />
                </a>
              )}
              {siteSettings.github_url && (
                <a 
                  href={siteSettings.github_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-muted-foreground hover:text-crypto-blue transition-colors"
                  aria-label="GitHub"
                >
                  <Github className="w-5 h-5" />
                </a>
              )}
            </div>
          </div>
        </div>

        <div className="border-t mt-8 pt-8 text-center">
          <p className="text-muted-foreground text-sm">&copy; 2024 {siteSettings.site_name}. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}