#!/bin/bash

# PostgreSQL Configuration Fix for VPS
set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${YELLOW}🔧 Fixing PostgreSQL configuration...${NC}"

# Find PostgreSQL version and config path
PG_VERSION=$(sudo -u postgres psql -t -c "SELECT version();" | grep -oP '\d+\.\d+' | head -1)
echo -e "${YELLOW}📦 Detected PostgreSQL version: ${PG_VERSION}${NC}"

# Find configuration directory
PG_CONFIG_DIR=""
for dir in /etc/postgresql/${PG_VERSION}/main /etc/postgresql/*/main; do
    if [ -d "$dir" ]; then
        PG_CONFIG_DIR="$dir"
        break
    fi
done

if [ -z "$PG_CONFIG_DIR" ]; then
    echo -e "${RED}❌ Could not find PostgreSQL configuration directory${NC}"
    echo -e "${YELLOW}📁 Searching for alternative locations...${NC}"
    find /etc -name "postgresql.conf" 2>/dev/null | head -5
    exit 1
fi

echo -e "${GREEN}✅ Found PostgreSQL config at: ${PG_CONFIG_DIR}${NC}"

# Configure PostgreSQL for remote connections
POSTGRESQL_CONF="${PG_CONFIG_DIR}/postgresql.conf"
PG_HBA_CONF="${PG_CONFIG_DIR}/pg_hba.conf"

if [ -f "$POSTGRESQL_CONF" ]; then
    echo -e "${YELLOW}⚙️ Configuring PostgreSQL for application access...${NC}"
    
    # Backup original configuration
    sudo cp "$POSTGRESQL_CONF" "${POSTGRESQL_CONF}.backup"
    
    # Enable local connections
    sudo sed -i "s/#listen_addresses = 'localhost'/listen_addresses = 'localhost'/g" "$POSTGRESQL_CONF"
    sudo sed -i "s/#port = 5432/port = 5432/g" "$POSTGRESQL_CONF"
    
    echo -e "${GREEN}✅ PostgreSQL configuration updated${NC}"
else
    echo -e "${RED}❌ PostgreSQL configuration file not found at ${POSTGRESQL_CONF}${NC}"
fi

if [ -f "$PG_HBA_CONF" ]; then
    echo -e "${YELLOW}🔐 Configuring authentication...${NC}"
    
    # Backup original pg_hba.conf
    sudo cp "$PG_HBA_CONF" "${PG_HBA_CONF}.backup"
    
    # Ensure local connections are allowed
    if ! grep -q "local.*all.*cryptohub_user.*md5" "$PG_HBA_CONF"; then
        echo "local   all             cryptohub_user                          md5" | sudo tee -a "$PG_HBA_CONF"
    fi
    
    if ! grep -q "host.*all.*cryptohub_user.*127.0.0.1/32.*md5" "$PG_HBA_CONF"; then
        echo "host    all             cryptohub_user  127.0.0.1/32            md5" | sudo tee -a "$PG_HBA_CONF"
    fi
    
    echo -e "${GREEN}✅ Authentication configuration updated${NC}"
else
    echo -e "${RED}❌ pg_hba.conf file not found at ${PG_HBA_CONF}${NC}"
fi

# Restart PostgreSQL
echo -e "${YELLOW}🔄 Restarting PostgreSQL...${NC}"
sudo systemctl restart postgresql

# Test connection
echo -e "${YELLOW}🧪 Testing database connection...${NC}"
if sudo -u postgres psql -c "SELECT 1;" > /dev/null 2>&1; then
    echo -e "${GREEN}✅ PostgreSQL is running and accessible${NC}"
else
    echo -e "${RED}❌ PostgreSQL connection test failed${NC}"
    exit 1
fi

echo -e "${GREEN}🎉 PostgreSQL configuration completed successfully!${NC}"