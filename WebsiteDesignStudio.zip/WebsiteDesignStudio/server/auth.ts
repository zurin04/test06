import bcrypt from "bcryptjs";
import { storage } from "./storage";
import { signupSchema, loginSchema, web3LoginSchema, type SignupData, type LoginData, type Web3LoginData, type User } from "@shared/schema";
import { ethers } from "ethers";
import type { Request, Response, NextFunction } from "express";

// Password utilities
export const hashPassword = async (password: string): Promise<string> => {
  return await bcrypt.hash(password, 12);
};

export const verifyPassword = async (password: string, hashedPassword: string): Promise<boolean> => {
  return await bcrypt.compare(password, hashedPassword);
};

// Web3 signature verification
export const verifySignature = (message: string, signature: string, address: string): boolean => {
  try {
    const recoveredAddress = ethers.verifyMessage(message, signature);
    return recoveredAddress.toLowerCase() === address.toLowerCase();
  } catch (error) {
    return false;
  }
};

// Generate unique user ID
export const generateUserId = (): string => {
  return `user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
};

// Authentication functions
export const registerUser = async (data: SignupData): Promise<User> => {
  const existingUser = await storage.getUserByEmail(data.email);
  if (existingUser) {
    throw new Error("User with this email already exists");
  }

  const hashedPassword = await hashPassword(data.password);
  const userId = generateUserId();

  const user = await storage.createUser({
    id: userId,
    email: data.email,
    password: hashedPassword,
    firstName: data.firstName,
    lastName: data.lastName,
    role: "user",
    isActive: true,
  });

  return user;
};

export const loginUser = async (data: LoginData): Promise<User> => {
  const user = await storage.getUserByEmail(data.email);
  if (!user) {
    throw new Error("Invalid email or password");
  }

  if (!user.password) {
    throw new Error("This account uses Web3 authentication");
  }

  const isValidPassword = await verifyPassword(data.password, user.password);
  if (!isValidPassword) {
    throw new Error("Invalid email or password");
  }

  if (!user.isActive) {
    throw new Error("Account is deactivated");
  }

  return user;
};

export const web3Login = async (data: Web3LoginData): Promise<User> => {
  const isValidSignature = verifySignature(data.message, data.signature, data.walletAddress);
  if (!isValidSignature) {
    throw new Error("Invalid signature");
  }

  let user = await storage.getUserByWallet(data.walletAddress);
  
  if (!user) {
    // Create new user with wallet
    const userId = generateUserId();
    user = await storage.createUser({
      id: userId,
      walletAddress: data.walletAddress,
      firstName: `User`,
      lastName: data.walletAddress.slice(-4),
      role: "user",
      isActive: true,
    });
  }

  if (!user.isActive) {
    throw new Error("Account is deactivated");
  }

  return user;
};

// Role-based authorization middleware
export const requireRole = (allowedRoles: string[]) => {
  return (req: any, res: Response, next: NextFunction) => {
    const user = req.user;
    
    if (!user) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    if (!allowedRoles.includes(user.role)) {
      return res.status(403).json({ message: "Insufficient permissions" });
    }

    next();
  };
};

// Check if user can create posts
export const canCreatePosts = (userRole: string): boolean => {
  return ["admin", "creator"].includes(userRole);
};

// Check if user is admin
export const isAdmin = (userRole: string): boolean => {
  return userRole === "admin";
};

// Middleware to attach user to request
export const attachUser = async (req: any, res: Response, next: NextFunction) => {
  try {
    if (req.session?.user?.id) {
      const user = await storage.getUser(req.session.user.id);
      if (user && user.isActive) {
        req.user = user;
      }
    }
    next();
  } catch (error) {
    next();
  }
};