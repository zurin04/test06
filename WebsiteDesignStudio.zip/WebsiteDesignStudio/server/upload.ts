import multer from 'multer';
import sharp from 'sharp';
import path from 'path';
import fs from 'fs/promises';
import { Request } from 'express';

// Create uploads directory if it doesn't exist
const uploadDir = path.join(process.cwd(), 'uploads');
fs.mkdir(uploadDir, { recursive: true }).catch(console.error);

// Configure multer for memory storage
const storage = multer.memoryStorage();

const upload = multer({
  storage,
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
  },
  fileFilter: (req: Request, file: Express.Multer.File, cb: multer.FileFilterCallback) => {
    // Accept only image files
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed!'));
    }
  },
});

// Function to process and save image
export const processAndSaveImage = async (
  buffer: Buffer,
  filename: string,
  options: {
    width?: number;
    height?: number;
    quality?: number;
  } = {}
): Promise<string> => {
  const { width = 800, height = 600, quality = 80 } = options;
  
  // Generate unique filename
  const timestamp = Date.now();
  const ext = '.webp';
  const processedFilename = `${timestamp}_${filename.replace(/\.[^/.]+$/, "")}${ext}`;
  const filePath = path.join(uploadDir, processedFilename);
  
  // Process image with sharp
  await sharp(buffer)
    .resize(width, height, {
      fit: 'inside',
      withoutEnlargement: true
    })
    .webp({ quality })
    .toFile(filePath);
  
  // Return relative path for URL
  return `/uploads/${processedFilename}`;
};

// Middleware for profile image upload
export const uploadProfileImage = upload.single('profileImage');

// Middleware for logo upload
export const uploadLogo = upload.single('logo');

// Function to process profile image
export const processProfileImage = async (file: Express.Multer.File): Promise<string> => {
  return processAndSaveImage(file.buffer, file.originalname, {
    width: 400,
    height: 400,
    quality: 85
  });
};

// Function to process logo
export const processLogo = async (file: Express.Multer.File): Promise<string> => {
  return processAndSaveImage(file.buffer, file.originalname, {
    width: 200,
    height: 200,
    quality: 90
  });
};

export default upload;