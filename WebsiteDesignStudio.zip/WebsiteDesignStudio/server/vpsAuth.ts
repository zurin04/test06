import session from "express-session";
import connectPg from "connect-pg-simple";
import type { Express, RequestHandler } from "express";

// VPS-only authentication setup - no Replit dependencies
export function getVPSSession() {
  const sessionTtl = 7 * 24 * 60 * 60 * 1000; // 1 week
  const pgStore = connectPg(session);
  const sessionStore = new pgStore({
    conString: process.env.DATABASE_URL,
    createTableIfMissing: false,
    ttl: sessionTtl,
    tableName: "sessions",
  });
  
  return session({
    secret: process.env.SESSION_SECRET || 'fallback-secret-change-in-production',
    store: sessionStore,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production', // Only use secure cookies in production
      maxAge: sessionTtl,
    },
  });
}

export function setupVPSAuth(app: Express) {
  app.set("trust proxy", 1);
  app.use(getVPSSession());
  console.log("VPS authentication setup complete - using email/Web3 only");
}

export const isVPSAuthenticated: RequestHandler = async (req: any, res, next) => {
  if (req.session?.user) {
    return next();
  }
  return res.status(401).json({ message: "Unauthorized" });
};